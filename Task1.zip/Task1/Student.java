class Student extends Person
{
	String program;
	int year;
	double fee;
	public Student(String name,String address,String program,int year,double fee)
	{
		super(name,address);
		this.program=program;
		this.year=year;
		this.fee=fee;
	}
	public String getProgram()
	{
		return program;
	}
	public void setProgram(String program)
	{
		this.program=program;
	}
	public int getYear()
	{
		return year;
	}
	public void setYear(int year)
	{
		this.year=year;
	}
	public double getFee()
	{
		return fee;
	}
	public void setFee(double fee)
	{
		this.fee=fee;
	}
	public String toString()
	{
		System.out.println("Name:"+getName());
		System.out.println("Address:"+getAddress());
		System.out.println("Program:"+getProgram());
		System.out.println("Year:"+getYear());
		System.out.println("Fee:"+getFee());
		return name;
	}
	public static void main(String args[])
	{
		Student s=new Student("phani","Vizag","CSE",4,32000);
		s.toString();
	}
}		
			