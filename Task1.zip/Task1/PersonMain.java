class PersonMain
{
	public static void main(String args[])
	{
		Person p=new Person("phani","REC");
		System.out.println(p.toString());
		Student stu=new Student("phani","Vizag","CSE",4,32000);
		System.out.println(stu.toString());
		Staff stf=new Staff("phani","Vizag","REC",32000);
		System.out.println(stf.toString()); 
	}
}