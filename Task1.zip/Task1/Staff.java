class Staff extends Person
{
	String school;
	double pay;
	public Staff(String name,String address,String school,double pay)
	{
		super(name,address);
		this.school=school;
		this.pay=pay;
	}
	public String getSchool()
	{
		return school;
	}
	public void setSchool(String school)
	{
		this.school=school;
	}
	public double getPay()
	{
		return pay;
	}
	public void setPay(double pay)
	{
		this.pay=pay;
	}
	public String toString()
	{
		
		return "Staff[Person[name=" + getName() + ",address=" + getAddress() + "],School=" +getSchool()+",Pay="+getPay() + "]";
	}
	public static void main(String args[])
	{
		Staff s=new Staff("phani","Vizag","REC",32000);
		System.out.println(s.toString()); 
	}
}		
			