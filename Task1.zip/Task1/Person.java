class Person
{
	String name;
	String address;
	public Person(String name,String address)
	{
		this.name=name;
		this.address=address;
	}
	public String getName()
	{
		return name;
	}
	public String getAddress()
	{
		return address;
	}
	public void setAddress(String address)
	{
		this.address=address;
		System.out.println("Address after set:"+address);
	}
	public String toString()
	{
		System.out.println("Name:"+getName());
		System.out.println("Address:"+getAddress());
		return name;
	}
		
	public static void main(String args[])
	{
		Person p=new Person("phani","REC");
		p.toString();
		p.setAddress("Raghu Engineering College");
	}
}
		