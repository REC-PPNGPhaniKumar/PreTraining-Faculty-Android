class Person
{
	String name;
	String address;
	public Person(String name,String address)
	{
		this.name=name;
		this.address=address;
	}
	public String getName()
	{
		return name;
	}
	public String getAddress()
	{
		return address;
	}
	public void setAddress(String address)
	{
		this.address=address;
		System.out.println("Address after set:"+address);
	}
	public String toString()
	{
		
		return "Person[name=" + getName() + ",address=" + getAddress() + "]";
	}
		
	public static void main(String args[])
	{
		Person p=new Person("phani","REC");
		System.out.println(p.toString());
		
		p.setAddress("Raghu Engineering College");
	}
}
		