package phani.spin;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

public class SpinnerAppActivity extends Activity {
	String arr[]={"C","CPP","JAVA","Python","Android"};
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Spinner lv=(Spinner) findViewById(R.id.sp);
        ArrayAdapter<String> aa=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,arr);
        lv.setAdapter(aa);
    }
}