class ShapeMain
{
	public static void main(String args[])
	{
		Circle c=new Circle(20,"Green",true);
		System.out.println(c.toString());
		Rectangle r1=new Rectangle(20,30);
		Rectangle r2=new Rectangle(20,30,"Green",true);
		System.out.println(r2.toString());
		Square s1=new Square(20);
		Square s2=new Square(20.0,"Green",true);
		System.out.println(s2.toString());
	}
}