class Rectangle extends Shape
{
	double width;
	double length;
	public Rectangle()
	{
		System.out.println("Rectangle Class");
	}
	public Rectangle(double width,double length)
	{
		this.color=color;
		this.filled=filled;
	}
	public Rectangle(double width,double length,String color,boolean filled)
	{
		super(color,filled);
		this.color=color;
		this.filled=filled;
		this.width=width;
		this.length=length;
		
	}
	public String getColor()
	{
		return color;
	}
	public void setColor(String color)
	{
		this.color=color;
	}
	public boolean isFilled()
	{
		return filled;
	}
	public void setFilled(boolean filled)
	{
		this.filled=filled;
	}
	public double getWidth()
	{
		return width;
	}
	public void setWidth(double width)
	{
		this.width=width;
	}
	public double getLength()
	{
		return length;
	}
	public void setLength(double length)
	{
		this.length=length;
	}
	public double getArea()
	{
		return length*width;
	
	}	
	public double getPerimeter()
	{
		return 2*(length+width);
	
	}
	public String toString()
	{
		System.out.println("Width of rectangle is:"+getWidth());
		System.out.println("Length of rectangle is:"+getLength());
		System.out.println("Area of rectangle is:"+getArea());
		System.out.println("Perimeter of rectangle is:"+getPerimeter());
		return "1";
	}
	public static void main(String args[])
	{
		Rectangle r1=new Rectangle(20,30);
		Rectangle r2=new Rectangle(20,30,"Green",true);
		r2.toString();		
	}
}	