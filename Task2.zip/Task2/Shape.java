abstract class Shape
{
	String color;
	boolean filled;
	public Shape()
	{
		System.out.println("From Abstract Class Shape");
	}
	public Shape(String color,boolean filled)
	{
		this.color=color;
		this.filled=filled;
	}
	abstract public String getColor();
	abstract public void setColor(String color);
	abstract public boolean isFilled();
	abstract public void setFilled(boolean filled);
	abstract public double getArea();
	abstract public double getPerimeter();
	abstract public String toString();
}

