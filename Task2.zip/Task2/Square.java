class Square extends Rectangle
{
	double side;
	public Square()
	{
		System.out.println("Square Class");
	}
	public Square(double side)
	{
		this.side=side;
	}
	public Square(double side,String color,boolean filled)
	{
		this.side=side;
		this.color=color;
		this.filled=filled;
	}
	public double getSide()
	{
		return side;
	}
	public void setSide(double side)
	{
		this.side=side;
	}
	public void setWidth(double width)
	{
		this.width=width;
	}
	public void setLength(double length)
	{
		this.length=length;
	}
	public double getArea()
	{
		return side*side;
	
	}	
	public double getPerimeter()
	{
		return 4*side;
	
	}
	public String toString()
	{
		System.out.println("Side of Square is:"+getSide());
		System.out.println("Area of Square is:"+getArea());
		System.out.println("Perimeter of Square is:"+getPerimeter());
		return "1";
	}
	public static void main(String args[])
	{
		Square s1=new Square(20);
		Square s2=new Square(20.0,"Green",true);
		s2.toString();		
	}
}	